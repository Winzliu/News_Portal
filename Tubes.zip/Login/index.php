<?php
session_start();
require '../koneksi.php';


if (isset($_SESSION["login"])) {
  // user
  $idUser = $_SESSION["id"];
  $users = mysqli_query($conn, "SELECT * FROM user WHERE id = '$idUser'");
  $user = mysqli_fetch_assoc($users);
  if (isset($user['id'])) {
    header("Location: ../HalamanUtama/index.php");
    exit;
  } else {
    header("Location: ../logout.php");
  }
}

if (isset($_POST["login"])) {
  if (login($_POST) == 0) {
    $error = true;
  }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Merienda+One&family=Noto+Serif&display=swap" rel="stylesheet">
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>ToSee Login</title>
  <link rel="stylesheet" href="css/style.css" />
  <link rel="stylesheet" href="css/mystyle.css" />
</head>

<body style="font-family: 'Noto Serif',serif;">
  <!-- Warna Yang Digunakan -->
  <!-- 
      Red 500     :#ef4444
      Amber 300   :#ffe4e6
      Emerald 100 :#d1fae5
      Rose 200    :#fcd34d
    -->
  <!-- Container Seluruh Layar -->
  <div class="flex w-screen h-screen container m-auto">
    <!-- Container Content -->
    <div class="m-auto p-7 box-border container" style="margin-top: 0px; max-width: 500px;">
      <!-- Judul -->
      <!-- <h1 class="text-7xl text-center mb-7 " style="font-family: 'Merienda One', cursive;">ToSee News</h1> -->
      <img class="m-auto" width="200px" src="../img/Logo-Tulisan.png" alt="">
      <!-- Kotak Login -->
      <div class="rounded-xl max-w-full p-7 m-auto bg-slate-50">
        <!-- Judul Kotak Login -->
        <h2 class="text-2xl text-center font-playfair font-bold">LOGIN</h2>
        <!-- Kotak Inputan -->
        <div class="h-60 justify-evenly flex flex-col">
          <!-- form -->
          <form action="" method="post">
            <!-- Email -->
            <div>
              <label for="username" class="font-playfair font-bold">Username</label><br />
              <input autofocus autocomplete="off" name="username" id="username" type="text" placeholder="Username"
                class="peer mt-1 block w-full px-3 py-2 border-b-2 bg-slate-100 border-amber-50 rounded-md text-sm shadow-xl placeholder-slate-500 focus:outline-none focus:bg-slate-200 focus:border-sky-300 focus:ring-1 focus:ring-sky-400 focus:border-2 disabled:bg-slate-50 disabled:text-slate-500 disabled:border-slate-200 valid:border-sky-400 valid:border-b-2 valid:bg-slate-200 disabled:shadow-none invalid:border-pink-500 invalid:text-pink-600 focus:invalid:border-pink-500 focus:invalid:ring-pink-500 transition-all duration-150"
                required />
              <p class="mt-2 invisible peer-invalid:visible text-pink-600 text-sm">
                Username Tidak Boleh Kosong.
              </p>
            </div>
            <!-- Password -->
            <div style="position: relative;">
              <label for="password" class="font-playfair font-bold">Password</label><br />
              <div style="position: relative;">
                <input minlength="8" name="password" id="password" type="password" placeholder="********" required
                  class="peer mt-1 block w-full px-3 py-2 border-b-2 bg-slate-100 border-amber-50 rounded-md text-sm shadow-xl placeholder-slate-500 focus:outline-none focus:bg-slate-200 focus:border-sky-300 focus:ring-1 focus:ring-sky-400 focus:border-2 disabled:bg-slate-50 disabled:text-slate-500 disabled:border-slate-200 valid:border-sky-400 valid:border-b-2 valid:bg-slate-200 disabled:shadow-none invalid:border-pink-500 invalid:text-pink-600 focus:invalid:border-pink-500 focus:invalid:ring-pink-500 transition-all duration-150" />
                <button type="button"
                  style="position: absolute; top: 7px; right: 20px;transition: .3s; font-size: 17px;"
                  onclick="showPassword()"><ion-icon id="icon" name="eye-outline"></ion-icon></button>
                <p class="mt-2 invisible peer-invalid:visible text-pink-600 text-sm">
                  Kata Sandi Harus Berisi Minimal 8 Karakter
                </p>
              </div>
            </div>
            <!-- sign up -->
            <p style="text-align: end;">
              <a class="text-blue-500 drop-shadow-xl font-bold" href="lupa.php">Lupa Password?</a>
            </p>
        </div>
        <?php if (isset($error)): ?>
        <p style="color: red; font-style: italic;margin-bottom: 1rem; text-align: center;">Username/Password Salah</p>
        <?php endif ?>
        <!-- Button Login-->
        <div class="flex flex-col gap-6">
          <button name="login" type="submit"
            class="hover:bg-slate-700 transition-colors rounded-lg w-1/3 h-10 m-auto bg-black font-playfair shadow-2xl text-white duration-150">
            Login
          </button>
          </form>
          <!-- akhir form -->
          <!-- sign up -->
          <p class="text-center">
            Belum Punya Akun?
            <a class="text-blue-500 drop-shadow-xl font-bold" href="../Registrasi/">Buat Akun</a>
          </p>
        </div>
      </div>
    </div>
  </div>
  <!-- script-ion-icons -->
  <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
  <!-- showpassword -->
  <script>
    function showPassword() {
      let icon = document.getElementById('icon');
      let password = document.getElementById('password');
      if (password.getAttribute("type") === 'password') {
        password.setAttribute("type", "text")
        icon.setAttribute("name", "eye-off-outline")
      } else {
        password.setAttribute("type", "password")
        icon.setAttribute("name", "eye-outline")
      }
    }
  </script>
</body>

</html>