<?php
session_start();

require '../koneksi.php';

if (isset($_POST["register"])) {
  if (registrasi($_POST) > 0) {
    $_SESSION["regis"] = true;
  }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Merienda+One&family=Noto+Serif&display=swap" rel="stylesheet">
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>ToSee Registrasi</title>
  <link rel="stylesheet" href="css/style.css" />
  <link rel="stylesheet" href="css/mystyle.css" />
</head>

<body style="font-family: 'Noto Serif', serif;">
  <!-- Warna Yang Digunakan -->
  <!-- 
      Red 500     :#ef4444
      Amber 300   :#ffe4e6
      Emerald 100 :#d1fae5
      Rose 200    :#fcd34d
    -->
  <!-- Container Seluruh Layar -->
  <div class="flex w-screen h-screen container m-auto">
    <!-- Container Content -->
    <div class="m-auto w-4/5 xl:w-3/5 box-border" style="max-width: 600px;">
      <!-- Judul -->
      <!-- <h1 class="text-7xl text-center mb-7 font-playfair ">Nama Brand</h1> -->
      <img class="m-auto" width="200px" src="../img/Logo-Tulisan.png" alt="">
      <!-- Kotak Registrasi -->
      <div class="rounded-xl max-w-full p-7 m-auto bg-slate-50">
        <!-- Judul Kotak Registrasi -->
        <h2 class="text-2xl text-center font-playfair font-bold">
          Registrasi
        </h2>
        <!-- Kotak Inputan -->
        <div class="justify-evenly flex flex-col">
          <form action="" method="post">
            <!-- Alamat Email -->
            <div>
              <label for="email" class="font-playfair font-bold">Alamat Email :</label><br />
              <input autofocus name="email" id="email" type="email" placeholder="email@gmail.com" required
                class="peer mt-1 block w-full px-3 py-2 border-b-2 bg-slate-100 border-amber-50 rounded-md text-sm shadow-xl placeholder-slate-500 focus:outline-none focus:bg-slate-200 focus:border-sky-300 focus:ring-1 focus:ring-sky-400 focus:border-2 disabled:bg-slate-50 disabled:text-slate-500 disabled:border-slate-200 valid:border-sky-400 valid:border-b-2 valid:bg-slate-200 disabled:shadow-none invalid:border-pink-500 invalid:text-pink-600 focus:invalid:border-pink-500 focus:invalid:ring-pink-500 transition-all duration-150" />
              <p class="mt-2 mb-3 invisible peer-invalid:visible text-pink-600 text-sm">
                Alamat Email Tidak Boleh Kosong
              </p>
            </div>
            <!-- Username -->
            <div>
              <label for="username" class="font-playfair font-bold">Username :</label><br />
              <input autocomplete="off" name="username" id="username" type="text" placeholder="Masukkan Nama Anda"
                required
                class="peer mt-1 block w-full px-3 py-2 border-b-2 bg-slate-100 border-amber-50 rounded-md text-sm shadow-xl placeholder-slate-500 focus:outline-none focus:bg-slate-200 focus:border-sky-300 focus:ring-1 focus:ring-sky-400 focus:border-2 disabled:bg-slate-50 disabled:text-slate-500 disabled:border-slate-200 valid:border-sky-400 valid:border-b-2 valid:bg-slate-200 disabled:shadow-none invalid:border-pink-500 invalid:text-pink-600 focus:invalid:border-pink-500 focus:invalid:ring-pink-500 transition-all duration-150" />
              <p class="mt-2 mb-3 invisible peer-invalid:visible text-pink-600 text-sm">
                Username Tidak Boleh Kosong
              </p>
            </div>

            <!-- Kata sandi -->
            <div>
              <label for="password" class="font-playfair font-bold">Kata Sandi :</label><br />
              <div style="position: relative;">
                <input minlength="8" name="password" id="password" type="password" placeholder="********" required
                  class="peer mt-1 block w-full px-3 py-2 border-b-2 bg-slate-100 border-amber-50 rounded-md text-sm shadow-xl placeholder-slate-500 focus:outline-none focus:bg-slate-200 focus:border-sky-300 focus:ring-1 focus:ring-sky-400 focus:border-2 disabled:bg-slate-50 disabled:text-slate-500 disabled:border-slate-200 valid:border-sky-400 valid:border-b-2 valid:bg-slate-200 disabled:shadow-none invalid:border-pink-500 invalid:text-pink-600 focus:invalid:border-pink-500 focus:invalid:ring-pink-500 transition-all duration-150" />
                <button type="button"
                  style="position: absolute; top: 7px; right: 20px;transition: .3s; font-size: 17px;"
                  onclick="showPassword()"><ion-icon id="icon" name="eye-outline"></ion-icon></button>
                <p class="mt-2 invisible peer-invalid:visible text-pink-600 text-sm">
                  Kata Sandi Harus Berisi Minimal 8 Karakter
                </p>
              </div>
            </div>

            <!-- Konfirmasi Kata Sandi -->
            <div style="margin-top: 15px;margin-bottom: 25px;">
              <label for="password2" class="font-playfair font-bold">Konfirmasi Kata Sandi :</label><br />
              <div style="position: relative;">
                <input minlength="8" name="password2" id="password2" type="password" placeholder="********" required
                  class="peer mt-1 block w-full px-3 py-2 border-b-2 bg-slate-100 border-amber-50 rounded-md text-sm shadow-xl placeholder-slate-500 focus:outline-none focus:bg-slate-200 focus:border-sky-300 focus:ring-1 focus:ring-sky-400 focus:border-2 disabled:bg-slate-50 disabled:text-slate-500 disabled:border-slate-200 valid:border-sky-400 valid:border-b-2 valid:bg-slate-200 disabled:shadow-none invalid:border-pink-500 invalid:text-pink-600 focus:invalid:border-pink-500 focus:invalid:ring-pink-500 transition-all duration-150" />
                <button type="button"
                  style="position: absolute; top: 7px; right: 20px;transition: .3s; font-size: 17px;"
                  onclick="showPassword2()"><ion-icon id="icon2" name="eye-outline"></ion-icon></button>
                <p class="mt-2 invisible peer-invalid:visible text-pink-600 text-sm">
                  Kata Sandi Harus Berisi Minimal 8 Karakter
                </p>
              </div>
            </div>

        </div>

        <!-- Button Login & Text Sign Up -->
        <div class="flex flex-col gap-6">
          <button type="submit" name="register"
            class="hover:bg-slate-700 transition-colors rounded-md h-10 m-auto bg-black text-white font-playfair shadow-2xl mb-7 px-3"
            onclick="kondisi()">
            Registrasi
          </button>
        </div>
        </form>
        <p class="text-center">
          Sudah Punya Akun?
          <a class="text-blue-500 drop-shadow-xl font-bold" href="../Login/">Silahkan Login</a>
        </p>
      </div>
    </div>
  </div>
  <!-- sweetalert -->
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

  <!-- jika ada session sukses maka tampilkan sweet alert dengan pesan yang telah di set
    di dalam session sukses  -->
  <?php if (isset($_POST['register'])): ?>
  <?php if (isset($_SESSION['regis'])): ?>
  <script>
    swal("Registrasi Berhasil", "Silahkan Login", "success");
    setTimeout(function () {
      document.location = "../login";
    }, 2500)
  </script>
  <!-- jangan lupa untuk menambahkan unset agar sweet alert tidak muncul lagi saat di refresh -->
  <?php unset($_SESSION['regis']); ?>
  <?php else: ?>
  <script>
      <?php unset($_SESSION[' regis ']); ?>
  </script>
  <?php endif; ?>
  <?php endif; ?>

  <!-- script-ion-icons -->
  <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
  <!-- showpassword -->
  <script>
      function showPassword() {
        let icon = document.getElementById('icon');
        let password = document.getElementById('password');
        if (password.getAttribute("type") === 'password') {
          password.setAttribute("type", "text")
          icon.setAttribute("name", "eye-off-outline")
        } else {
          password.setAttribute("type", "password")
          icon.setAttribute("name", "eye-outline")
        }
      }
  </script>

  <!-- show konfirmasi password -->
  <script>
    function showPassword2() {
      let icon = document.getElementById('icon2');
      let password = document.getElementById('password2');
      if (password.getAttribute("type") === 'password') {
        password.setAttribute("type", "text")
        icon.setAttribute("name", "eye-off-outline")
      } else {
        password.setAttribute("type", "password")
        icon.setAttribute("name", "eye-outline")
      }
    }
  </script>
</body>

</html>